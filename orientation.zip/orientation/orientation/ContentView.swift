//
//  ContentView.swift
//  orientation
//
//  Created by Ian on 3/17/20.
//  Copyright © 2020 Ian. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, World!")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

override func
supportedInterfaceOrientations(
) -> UIInterfaceOrientationMask
{
    return UIInterfaceOrientationMask (rawValue: (UIInterfaceOrientationMask.portrait.rawValue)
        UIInterfaceOrientationMask.landscapeLeft.rawValue)
}
