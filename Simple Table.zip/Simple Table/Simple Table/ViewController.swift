//
//  ViewController.swift
//  Simple Table
//
//  Created by Ian on 4/6/20.
//  Copyright © 2020 Ian. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    UITableViewDelegate {
        private let dwarves = [
            "thorin", "grog", "gloin", "bofur"
        ]
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection: Int
    ) -> Int {
        return dwarves.count
    }

}

