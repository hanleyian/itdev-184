//
//  ViewController.swift
//  MyFirstApp
//
//  Created by Ian on 2/18/20.
//  Copyright © 2020 Ian. All rights reserved.
//

import Foundation
import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad(){
        super.viewDidLoad()
        let label = UILabel()
        label.frame = CGRect(x: 125, y: 125, width: 200, height: 80)
        label.text = "this is a label"
        view.addSubview(label)
        
        let button = UIButton()
        button.frame = CGRect(x: 125, y:300, width: 80, height: 80)
        button.setTitle("Button", for: .normal)
        view.addSubview(button)
    }
}
