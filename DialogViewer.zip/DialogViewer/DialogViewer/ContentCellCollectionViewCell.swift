//
//  ContentCellCollectionViewCell.swift
//  DialogViewer
//
//  Created by Ian on 4/28/20.
//  Copyright © 2020 Ian. All rights reserved.
//

import UIKit

class ContentCellCollectionViewCell: UICollectionViewCell {
    
}
