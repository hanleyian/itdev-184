//
//  ViewController.swift
//  DialogViewer
//
//  Created by Ian on 4/28/20.
//  Copyright © 2020 Ian. All rights reserved.
//

import UIKit

class ViewController: UICollectionViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        var contentInset =
            collectionView!.contentInset
        contentInset.top = 20
        collectionView!.contentInset = contentInset
    }
    
    private var sections = [
        [ "header": "one", "content" : "first"
        ],
        [ "header": "two", "content" : "second"
        ],
        [ "header": "three", "content" : "third"
        ],
        [ "header": "one", "content" : "one again"
        ],
        [ "header": "two", "content" : "two again"
        ],
        [ "header": "three", "content" : "three again"
            
        ]
        

    ]
    


}

