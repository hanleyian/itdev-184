//
//  FontListViewController.swift
//  fonts
//
//  Created by Ian on 4/23/20.
//  Copyright © 2020 Ian. All rights reserved.
//

import Foundation

class FontListViewController:
override func viewDidLoad(){
    super.viewDidLoad()
    
    let preferredTableViewFont =
        UIFont.preferredFont(forTextStyle: UIFontTextStyleHeadline)
    cellPointSize =
    preferredTableViewFont.pointSize
    tableView.estimatedRowHeight = cellPointSize
}
    
    
UITableViewController {
    var fontNames: [String] = []
    var showsFavorites:Bool = false
    private var cellPointSize: CGFloat!
    private static let cellIdentifier = "FontName"
}

func fontForDisplay(atIndexPath indexpath: NSIndexPath) -> UIFont {
    let fontName = fontNames[indexPath.row]
    return UIFont(name: fontName, size: cellpointsize)!
}


